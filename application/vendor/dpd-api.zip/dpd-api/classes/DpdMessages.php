<?php
class DpdMessages {
    /*
     * todo
     */
    public static $error = array(
        "pl_PL" => array(
            "1" => "Host musi być poprawnie uzupełniony"
        ),
        "en_EN" => array(
            "1" => "Host address must be set",
        )
    );
    
}
?>
