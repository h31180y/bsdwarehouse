<?php
require_once __DIR__.'/classes/Dpd.php';
Dpd::registerAutoload();
?>